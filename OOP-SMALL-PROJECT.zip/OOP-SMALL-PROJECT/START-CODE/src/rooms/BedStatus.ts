/**
 * The different status of a bed
 */
export enum BedStatus {
  GOOD = "Good",
  OPERATIONAL = "Operational",
  BROKEN = "Broken",
}

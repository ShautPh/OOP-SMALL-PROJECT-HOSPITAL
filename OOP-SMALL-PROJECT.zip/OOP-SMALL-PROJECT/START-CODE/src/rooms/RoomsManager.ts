import { Patient } from "../human/patient/Patient";
import { Room } from "./Room";

export class RoomsManager {
  public rooms: Room[] = [];

  getNumberOfRooms(): number {
    return this.rooms.length;
  }

  addRoom(room: Room) {
    return this.rooms.push(room);
  }

  /** Find a room with a free bed
   * @return the first room available with a free bed
   */
  findFreeRoom():Room | undefined {
    for (let room of this.rooms){
      for(let bed of room.getBeds()){
        if (!bed.hasPatient()){
          return room;
        }
      }
    }
    return undefined; // TODO
  }

  removePatient(patient: Patient) {
    for (let i = 0; i <this.rooms.length; i++) {
      let room = this.rooms[i].getBeds();
      for (let j = 0; j < room.length; j++){
        if (room[j].getPatient() === patient){
          room[j]['patient'] = undefined;
          return "Removed patient from bed";
        }
      }
    }
  }
}

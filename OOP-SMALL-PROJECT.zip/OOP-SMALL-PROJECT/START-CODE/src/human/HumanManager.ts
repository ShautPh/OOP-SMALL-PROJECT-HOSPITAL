import { Disease } from "../medical/Disease";
import { Patient } from "./patient/Patient";
import { Doctor } from "./staff/Doctor";
import { Staff } from "./staff/Staff";

export class HumanManager {
  private patients: Patient[] = [];
  private staffs: Staff[] = [];

  addPatient(patient: Patient) {
    this.patients.push(patient);
  }

  getPatients() {
    return this.patients;
  }

  addStaff(staff: Staff) {
    this.staffs.push(staff);
  }

  getStaffs() {
    return this.staffs;
  }

  /**
   *
   * @returns the first doctor found among the staff, having the given disease as speciality
   */
  getADoctorWithSkill(disease:Disease):Doctor | undefined{
    for (let staff of this.getStaffs()){
      let doctor = staff as Doctor;
      if (doctor.getSpeciality() === disease){
        return doctor;
      }
    }
    return undefined; //TODO
  }
}

// TEST THE MODEL HERE

import { DateTime } from "./calendar/DateTime";
import { DoctorAppointment } from "./calendar/DoctorAppointment";
import { EventCategory } from "./calendar/Event";
import { Hospital } from "./Hospital";
import { Patient } from "./human/patient/Patient";
import { Gender, Person } from "./human/Person";
import { Doctor } from "./human/staff/Doctor";
import { Nurse } from "./human/staff/Nurse";
import { StaffCategory } from "./human/staff/Staff";
import { Disease } from "./medical/Disease";
import { Bed } from "./rooms/Bed";
import { BedStatus } from "./rooms/BedStatus";
import { Room } from "./rooms/Room";

let hospital = new Hospital("Kosmak", "Phnom Penh");

let room1 = new Room(11);
let room2 = new Room(22);
let bed1 = new Bed(1);

bed1.setStatus(BedStatus.OPERATIONAL);
let bed2 = new Bed(2);
bed2.setStatus(BedStatus.BROKEN);
let bed3 = new Bed(3);
let bed4 = new Bed(4);
bed3.setStatus(BedStatus.OPERATIONAL);

room1.addBed(bed1);
room1.addBed(bed2);
room2.addBed(bed3);
room2.addBed(bed4);

hospital.rooms.addRoom(room1)
hospital.rooms.addRoom(room2)

let rady = new Patient('Rady', 28,Gender.MALE);
rady.addDisease(Disease.STOMACH);
rady.addDisease(Disease.EYES);
hospital.hr.addPatient(rady);
bed1.setPatient(rady);

let vannsao = new Patient('Vannsao', 22,Gender.MALE);
vannsao.addDisease(Disease.STOMACH);
hospital.hr.addPatient(vannsao);
bed2.setPatient(vannsao);

let jeanne = new Patient('Jeanne', 28,Gender.FEMALE);
jeanne.addDisease(Disease.TEETH);
jeanne.addDisease(Disease.NOSE);
hospital.hr.addPatient(jeanne);
bed3.setPatient(jeanne);

let theavy = new Patient('Theavy', 23,Gender.FEMALE);
theavy.addDisease(Disease.TEETH);
hospital.hr.addPatient(theavy);
bed4.setPatient(theavy);

let him = new Doctor(StaffCategory.DOCTOR,'HIM',22,Gender.MALE);
him.setSpeciality(Disease.TEETH);
let sauth = new Doctor(StaffCategory.DOCTOR,'SAUTH',22,Gender.MALE);
sauth.setSpeciality(Disease.CANCER);
let ronan = new Nurse(StaffCategory.NURSE,'RONAN',22,Gender.MALE);
hospital.hr.addStaff(him);
hospital.hr.addStaff(sauth);
hospital.hr.addStaff(ronan);

let start = new DateTime(14,4,2022,8);
let end = new DateTime(14,4,2022,10);
let appointement = new DoctorAppointment(EventCategory.DOCTOR_APPOINTEMENT,start, end,him,jeanne);
hospital.calendar.addEvent(appointement);
console.log(hospital.hr.getPatients());
console.log(hospital);
console.log(hospital.rooms.removePatient(theavy));
console.log("Room free: ",hospital.rooms.findFreeRoom());
console.log(room1);
console.log(room2);
console.log(hospital.hr.getADoctorWithSkill(Disease.TEETH))
console.log(hospital.calendar.getAllAppointementFor(him));

console.log(hospital.calendar.isDoctorFree(him,start));